package com.example.SpringRest.enums;

public enum BookStatus {
    ON_HAND, RETURNED
}
