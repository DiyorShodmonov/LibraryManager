package com.example.SpringRest.repository;

import com.example.SpringRest.config.Config;
import com.example.SpringRest.model.Student;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.persistence.Query;
import java.io.Serializable;
import java.time.LocalDate;
import java.util.List;

@Repository
public class StudentRepository {
    @Autowired
    private SessionFactory sessionFactory;

    public int saveStudent(Student student) {
        Session session = sessionFactory.openSession();
        Transaction transaction = session.beginTransaction();

        student.setCreatedDate(LocalDate.now());
        Integer save =(Integer) session.save(student);

        transaction.commit();
        session.close();
        return save;
    }

    public List studentList() {
        Session session = sessionFactory.openSession();

        Query query = session.createQuery("From Student");
        List studentList = query.getResultList();
        session.close();


        if(studentList.isEmpty()){
            return null;
        }
        return studentList;
    }

    public Student getStudentById(Integer id) {
        Session session = sessionFactory.openSession();

        Student student = session.get(Student.class, id);
        return student;
    }

    public void deleteStudentById(Integer id) {
        Session session = sessionFactory.openSession();
        session.delete(getStudentById(id));

//        Query query = session.createQuery("DELETE from Student where id= :id");
//
//        query.setParameter("id", id);

    }
}
