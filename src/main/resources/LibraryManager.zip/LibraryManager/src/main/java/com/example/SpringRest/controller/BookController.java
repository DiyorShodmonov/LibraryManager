package com.example.SpringRest.controller;

public class BookController {

}
